


class Result():
    def __init__(self, title, subtitle=None, icon=None, launch=None):
        self.title = title
        self.subtitle = subtitle
        self.icon = icon
        self.launch = launch

