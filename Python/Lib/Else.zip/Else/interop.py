try:
    # attempt to import embedded C module
    from _else import on_register_plugin, app_commands
except ImportError:
    # import failed
    print("c extension not available")
    
    # define dummy objects (so our plugins can be executed without the c module)
    def on_register_plugin(plugin):
        pass

    class AppCommands():
        def __getattr__(self, attr):
            return lambda: print("AppCommand '{0}' is not available".format(attr))
    
    app_commands = AppCommands()

plugins = []
def register_plugin(plugin):
    from Else import Plugin
    if not isinstance(plugin, Plugin):
        raise TypeError("Plugin instance not derived from Else.Plugin")
    plugin.Setup()
    plugins.append(plugin)
    on_register_plugin(plugin)
    print("register plugin: {0} : {1}".format(plugins, id(plugin)))
